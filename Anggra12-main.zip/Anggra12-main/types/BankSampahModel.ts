export interface BankSampahModel {
  _id: string;
  nama: string;
  alamat: string;
  waktu: string;
  latitude: number;
  longitude: number;
}