export default function Title({ text }) { 
    return (
      <>
        <h1 className="font-poppins text-xs font-bold">{text}</h1>
      </>
    );
}